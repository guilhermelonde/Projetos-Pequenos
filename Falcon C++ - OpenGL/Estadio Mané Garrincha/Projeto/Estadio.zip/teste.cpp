/*
   Reprodu��o do est�dio Man� Garrincha de Bras�lia
   Autor: Guilherme Pereira Porto Londe
*/

#include <GL/glut.h>
#include <utility>
#include <cmath>
#include <algorithm>
#include <vector>
#include "tgaload.h"
#include <stdio.h>

using namespace std;

GLfloat ASPECTO, ANGULO;
int x_ini,y_ini, bot;
GLfloat obsX, obsY, obsZ, rotX, rotY;
GLfloat obsX_ini, obsY_ini, obsZ_ini, rotX_ini, rotY_ini;
GLfloat escalaX, escalaY, escalaZ;
#define SENS_ROT 10.0
#define SENS_OBS 10.0
#define SENS_TRANS 10.0

#define MAX_NO_TEXTURAS 6
#define MAX_NO_PANORAMAS 7

// Definem as macros para pontos geom�tricos
#define p2d pair<double,double>
#define p3d pair<p2d, double>
#define mkp(a, b, c) p3d(p2d(a, b), c)
#define x first
#define y second
#define x3 first.first
#define y3 first.second
#define z3 second

// Definem a retangularidade do campo. mulX igual a mulY ir�o gerar um campo quadrado
const double mulX = 0.79;
const double mulY = 1.0;

// Definem medidas fundamentais para a extrutura externa
const double distanciaTetoInterior = 45;
const double distanciaTetoInt1 = 70;
const double distanciaTetoInt2 = 140;
const double distanciaTetoExterior = 168;
const double alturaTeto = 50;
const int numFatiasExterior = 60;
const double alturaEstMetalica = 7;

GLuint texture_id[MAX_NO_TEXTURAS+MAX_NO_PANORAMAS];
int panorama_corrente;

class Background {
private:
	static inline p3d rotaciona(p3d A, double a1, double a2){
		a1 = a1*M_PI/180.0;
		a2 = a2*M_PI/180.0;
		double X = A.x3*cos(a1)+A.y3*sin(a1);
		double Y = A.x3*sin(a1)-A.y3*cos(a1);
		A.x3 = X;
		A.y3 = Y;
		X = A.x3*cos(a2)-A.z3*sin(a2);
		double Z = A.x3*sin(a2)+A.z3*cos(a2);
		A.x3 = X;
		A.z3 = Z;
		return A;
	}
public:
	static void desenhaBackground(){
		// Gera um visualizador de imagem 360.
		// Ir� desenhar uma esfera e texturiz�-la com uma imagem panor�mica 360 e usar parte dessa
		// esfera como a pr�pria superf�cie.
		glPushMatrix();
		glBindTexture ( GL_TEXTURE_2D, texture_id[MAX_NO_TEXTURAS+panorama_corrente] );
		int nF = 50;
		double d = 500;
		p3d X;
		X.x3 = 0; X.y3 = d; X.z3 = 0;
		for (int i = 0; i < nF; i++){
			for (int j = 0; j < 2*nF; j++){
				// A, B, C e D s�o quatro v�rtices de um pol�gono.
				p3d A = rotaciona(X, i*180.0/double(nF), j*180.0/double(nF));
				p3d B = rotaciona(X, i*180.0/double(nF), (j+1)*180.0/double(nF));
				p3d C = rotaciona(X, (i+1)*180.0/double(nF), (j+1)*180.0/double(nF));
				p3d D = rotaciona(X, (i+1)*180.0/double(nF), j*180.0/double(nF));
				// Normal � o centro de massa do pol�gono ABCD.
				p3d Normal = rotaciona(X, (double(i)+0.5)*180.0/double(nF), (double(j)+0.5)*180.0/double(nF));
				glBegin(GL_POLYGON);
				glColor3f(1.0f, 1.0f, 1.0f);
				if (i < double(nF)*0.43){
					// Parte da esfera (o polo sul) � invertido verticalmente e achatado.
					A.y3 = (-d-A.y3)*0.23;
					B.y3 = (-d-B.y3)*0.23;
					C.y3 = (-d-C.y3)*0.23;
					D.y3 = (-d-D.y3)*0.23;
				}
				// Projeta e texturiza o pol�gono ABCD. Ap�s todos os pol�gonos serem projetados ter� uma semi-esfera.
				glNormal3f(-Normal.x3, -Normal.y3, -Normal.z3);
				glTexCoord2f(j/double(2*nF), i/double(nF)); glVertex3f(A.x3, A.y3, A.z3);
				glTexCoord2f((j+1)/double(2*nF), i/double(nF)); glVertex3f(B.x3, B.y3, B.z3);
				glTexCoord2f((j+1)/double(2*nF), (i+1)/double(nF)); glVertex3f(C.x3, C.y3, C.z3);
				glTexCoord2f(j/double(2*nF), (i+1)/double(nF)); glVertex3f(D.x3, D.y3, D.z3);
				glEnd();
			}
		}
		glPopMatrix();
	}
};

class Estrutura {
public:
	static inline p2d rotaciona(p2d p, double theta){
		theta = theta*M_PI/180.0;
		p2d ans;
		ans.x = p.x * cos(theta) + p.y * sin(theta);
		ans.y = -p.x * sin(theta) + p.y * cos(theta);
		return ans;
	}

	static void geraLinhaDivisoria(p3d A, p3d B, double espessura = 0.001){
		glPushMatrix();
			glColor3f(0, 0, 0);
			glLineWidth(espessura);
			glBegin(GL_LINES);
			glVertex3f(A.x3, A.y3, A.z3);
			glVertex3f(B.x3, B.y3, B.z3);
			glEnd();
		glPopMatrix();
	}
};

class Exterior : Estrutura{
private:
	static void geraBasesTronco(int numFacesCilindroTeto, double r, double h, double anguloInicial, vector<p3d> &l1, vector<p3d> &l2){
		// Gera um semi-tronco que converge para a origem (0,0,0).
		// Ir� gerar a estrutura para o teto intermedi�rio.
		p2d BaseCilindroTeto[numFacesCilindroTeto+1];
		BaseCilindroTeto[0] = p2d(0, r);
		double maisDistante = 0;
		for (int i = 1; i <= numFacesCilindroTeto; i++){
			BaseCilindroTeto[i] = rotaciona(BaseCilindroTeto[i-1], 180.0/double(numFacesCilindroTeto));
			maisDistante = max(maisDistante, BaseCilindroTeto[i].x);
		}
		for (int i = 0; i <= numFacesCilindroTeto; i++){
			p2d p1, p2;
			p1 = p2 = BaseCilindroTeto[i];
			p1.x = 1.0 + p1.x/h - maisDistante/h;
			p2.x = 1.0 + maisDistante/h - p2.x/h;
			p1 = rotaciona(p1, anguloInicial);
			p2 = rotaciona(p2, anguloInicial);
			l1.push_back(p3d(p2d(p1.x, BaseCilindroTeto[i].x/h), p1.y));
			l2.push_back(p3d(p2d(p2.x, BaseCilindroTeto[i].x/h), p2.y));
		}
	}

public:
	static void geraFatia(double anguloInicial, double anguloFatia, double estTransparente){
		// Teto, pilastras e piso exterior
		int numFacesCilindroTeto = 6;
		double distanciaPisoInterior = 140;
		double distanciaPisoExterior = 168;
		double alturaPiso = 10;
		double distanciaPilastra1 = 148;
		double distanciaEntrePilastras = 9;
		int numFacesPilastra = 8;
		double raioPilastra = 0.8;

		p2d A = rotaciona(p2d(1, 0), anguloInicial);
		p2d B = rotaciona(A, anguloFatia);

		if (estTransparente){
            //Teto interior
            glColor4f(0.6, 0.6, 0.6, 0.5);
            glBegin(GL_POLYGON);
            glVertex3f(A.x*distanciaTetoInterior, alturaTeto, A.y*distanciaTetoInterior);
            glVertex3f(B.x*distanciaTetoInterior, alturaTeto, B.y*distanciaTetoInterior);
            glVertex3f(B.x*distanciaTetoInt1, alturaTeto, B.y*distanciaTetoInt1);
            glVertex3f(A.x*distanciaTetoInt1, alturaTeto, A.y*distanciaTetoInt1);
            glEnd();

            //Estrutura met�lica
            glColor4f(1, 1, 0.9, 0.8);
            glBegin(GL_POLYGON);
            glVertex3f(A.x*distanciaTetoInt1, alturaTeto-alturaEstMetalica, A.y*distanciaTetoInt1);
            glVertex3f(B.x*distanciaTetoInt1, alturaTeto-alturaEstMetalica, B.y*distanciaTetoInt1);
            glVertex3f(B.x*distanciaTetoInt2, alturaTeto, B.y*distanciaTetoInt2);
            glVertex3f(A.x*distanciaTetoInt2, alturaTeto, A.y*distanciaTetoInt2);
            glEnd();
            return;
		}

		//Estrutura met�lica
        glColor3f(1, 1, 1);
        glBegin(GL_POLYGON);
        glVertex3f(A.x*distanciaTetoInt1, alturaTeto, A.y*distanciaTetoInt1);
        glVertex3f(B.x*distanciaTetoInt1, alturaTeto, B.y*distanciaTetoInt1);
        glVertex3f(B.x*distanciaTetoInt1, alturaTeto-alturaEstMetalica, B.y*distanciaTetoInt1);
        glVertex3f(A.x*distanciaTetoInt1, alturaTeto-alturaEstMetalica, A.y*distanciaTetoInt1);
        glEnd();
		geraLinhaDivisoria(mkp(A.x*distanciaTetoInt1, alturaTeto-alturaEstMetalica, A.y*distanciaTetoInt1),
			mkp(B.x*distanciaTetoInt1, alturaTeto-alturaEstMetalica, B.y*distanciaTetoInt1), 2);
		geraLinhaDivisoria(mkp(A.x*distanciaTetoInt2, alturaTeto, A.y*distanciaTetoInt2),
			mkp(A.x*distanciaTetoInt1, alturaTeto-alturaEstMetalica, A.y*distanciaTetoInt1), 2);
		geraLinhaDivisoria(mkp(A.x*distanciaTetoInt1, alturaTeto, A.y*distanciaTetoInt1),
			mkp(A.x*distanciaTetoInt1, alturaTeto-alturaEstMetalica, A.y*distanciaTetoInt1), 2);
		geraLinhaDivisoria(mkp(A.x*distanciaTetoInterior, alturaTeto, A.y*distanciaTetoInterior),
			mkp(A.x*distanciaTetoInt1, alturaTeto-alturaEstMetalica/2.0, A.y*distanciaTetoInt1), 2);

		// Teto exterior
		glPushMatrix();
		glBindTexture ( GL_TEXTURE_2D, texture_id[2] );
		glColor3f(1, 1, 1);
		for (int i = 0; i < 2; i++){
			glBegin(GL_POLYGON);
			glTexCoord2f(0, 0); glVertex3f(A.x*distanciaTetoInt2, alturaTeto-i, A.y*distanciaTetoInt2);
			glTexCoord2f(0, 1); glVertex3f(B.x*distanciaTetoInt2, alturaTeto-i, B.y*distanciaTetoInt2);
			glTexCoord2f(3, 1); glVertex3f(B.x*distanciaTetoExterior, alturaTeto-i, B.y*distanciaTetoExterior);
			glTexCoord2f(3, 0); glVertex3f(A.x*distanciaTetoExterior, alturaTeto-i, A.y*distanciaTetoExterior);
			glEnd();
		}
		int u = distanciaTetoExterior-distanciaTetoInt2;
		for (int i = 0; i < 2; i++){
			glBegin(GL_POLYGON);
			glTexCoord2f(0, 0); glVertex3f(A.x*(distanciaTetoInt2+u*i), alturaTeto-1, A.y*(distanciaTetoInt2+u*i));
			glTexCoord2f(0, 1); glVertex3f(B.x*(distanciaTetoInt2+u*i), alturaTeto-1, B.y*(distanciaTetoInt2+u*i));
			glTexCoord2f(1, 1); glVertex3f(B.x*(distanciaTetoInt2+u*i), alturaTeto, B.y*(distanciaTetoInt2+u*i));
			glTexCoord2f(1, 0); glVertex3f(A.x*(distanciaTetoInt2+u*i), alturaTeto, A.y*(distanciaTetoInt2+u*i));
			glEnd();
		}
		geraLinhaDivisoria(mkp(A.x*distanciaTetoInterior, alturaTeto+0.1, A.y*distanciaTetoInterior),
			mkp(A.x*distanciaTetoExterior, alturaTeto+0.1, A.y*distanciaTetoExterior), 2.5);
		glPopMatrix();

		//Teto Intermediario (semi-tronco)
		vector<p3d> l1, l2;
		geraBasesTronco(numFacesCilindroTeto, hypot(A.x-B.x, A.y-B.y)/2.0, 2.5, anguloInicial + anguloFatia/2.0, l1, l2);
		for (int i = 0; i <= numFacesCilindroTeto; i++){
			l1[i].x3 *= distanciaTetoInt1;
			l1[i].y3 = l1[i].y3*distanciaTetoInt1 + alturaTeto;
			l1[i].z3 *= distanciaTetoInt1;
			l2[i].x3 *= distanciaTetoInt2;
			l2[i].y3 = l2[i].y3*distanciaTetoInt2 + alturaTeto;
			l2[i].z3 *= distanciaTetoInt2;
		}
		for (int i = 1; i <= numFacesCilindroTeto; i++){
			glPushMatrix();
			glBindTexture ( GL_TEXTURE_2D, texture_id[0] );
			glColor3f(1, 1, 1);
			glBegin(GL_POLYGON);
			glTexCoord2f(0, 0); glVertex3f(l1[i-1].x3, l1[i-1].y3, l1[i-1].z3);
			glTexCoord2f(0, 7); glVertex3f(l2[i-1].x3, l2[i-1].y3, l2[i-1].z3);
			glTexCoord2f(1, 7); glVertex3f(l2[i].x3, l2[i].y3, l2[i].z3);
			glTexCoord2f(1, 0); glVertex3f(l1[i].x3, l1[i].y3, l1[i].z3);
			glEnd();
			if (i > 1){
				glBegin(GL_TRIANGLES);
				glTexCoord2f(0.5, 0.5); glVertex3f(l1[0].x3, l1[0].y3, l1[0].z3);
				glTexCoord2f(0.5, 0.57); glVertex3f(l1[i-1].x3, l1[i-1].y3, l1[i-1].z3);
				glTexCoord2f(0.57, 0.57); glVertex3f(l1[i].x3, l1[i].y3, l1[i].z3);
				glEnd();
				glBegin(GL_TRIANGLES);
				glTexCoord2f(0.5, 0.5); glVertex3f(l2[0].x3, l2[0].y3, l2[0].z3);
				glTexCoord2f(0.5, 0.57); glVertex3f(l2[i-1].x3, l2[i-1].y3, l2[i-1].z3);
				glTexCoord2f(0.57, 0.57); glVertex3f(l2[i].x3, l2[i].y3, l2[i].z3);
				glEnd();
			}
			glPopMatrix();
			geraLinhaDivisoria(l1[i-1], l1[i], 0.5);
			geraLinhaDivisoria(l2[i-1], l2[i], 0.5);
		}
		int fc = numFacesCilindroTeto;
		geraLinhaDivisoria(mkp(l1[0].x3, l1[0].y3+0.1, l1[0].z3), mkp(l1[fc].x3, l1[fc].y3+0.1, l1[fc].z3), 2);
		geraLinhaDivisoria(mkp(l2[0].x3, l2[0].y3+0.1, l2[0].z3), mkp(l2[fc].x3, l2[fc].y3+0.1, l2[fc].z3), 5);

		//Piso exterior
		glPushMatrix();
		glBindTexture ( GL_TEXTURE_2D, texture_id[2] );
		glColor3f(0.6, 0.6, 0.6);
		for (int i = 0; i < 2; i++){
			glBegin(GL_POLYGON);
			glTexCoord2f(0, 0); glVertex3f(A.x*distanciaPisoInterior, alturaPiso-i, A.y*distanciaPisoInterior);
			glTexCoord2f(0, 1); glVertex3f(B.x*distanciaPisoInterior, alturaPiso-i, B.y*distanciaPisoInterior);
			glTexCoord2f(3, 1); glVertex3f(B.x*distanciaPisoExterior, alturaPiso-i, B.y*distanciaPisoExterior);
			glTexCoord2f(3, 0); glVertex3f(A.x*distanciaPisoExterior, alturaPiso-i, A.y*distanciaPisoExterior);
			glEnd();
		}
		int v = distanciaPisoExterior-distanciaPisoInterior;
		for (int i = 0; i < 2; i++){
			glBegin(GL_POLYGON);
			glTexCoord2f(0, 0); glVertex3f(A.x*(distanciaPisoInterior+v*i), alturaPiso-1, A.y*(distanciaPisoInterior+v*i));
			glTexCoord2f(0, 1); glVertex3f(B.x*(distanciaPisoInterior+v*i), alturaPiso-1, B.y*(distanciaPisoInterior+v*i));
			glTexCoord2f(1, 1); glVertex3f(B.x*(distanciaPisoInterior+v*i), alturaPiso, B.y*(distanciaPisoInterior+v*i));
			glTexCoord2f(1, 0); glVertex3f(A.x*(distanciaPisoInterior+v*i), alturaPiso, A.y*(distanciaPisoInterior+v*i));
			glEnd();
		}
		glPopMatrix();

		//6 pilastras
		glPushMatrix();
		glBindTexture ( GL_TEXTURE_2D, texture_id[2] );
		double ang = 360.0 / double(numFacesPilastra);
		for (int r = 0; r < 2; r++){
			A = rotaciona(A, r*anguloFatia/2.0);
			p2d C = p2d(raioPilastra, 0);
			for (int i = 0; i < numFacesPilastra; i++){
				p2d D = rotaciona(C, ang);
				for (int j = 0; j < 3; j++){
					double dist = distanciaPilastra1 + j * distanciaEntrePilastras;
					glColor3f(0.9, 0.9, 0.9);
					glBegin(GL_POLYGON);
					glTexCoord2f(0, 0); glVertex3f(C.x + A.x*dist, -alturaPiso, C.y+A.y*dist);
					glTexCoord2f(0, 1); glVertex3f(D.x + A.x*dist, -alturaPiso, D.y+A.y*dist);
					glTexCoord2f(alturaTeto*2, 1); glVertex3f(D.x + A.x*dist, alturaTeto, D.y+A.y*dist);
					glTexCoord2f(alturaTeto*2, 0); glVertex3f(C.x + A.x*dist, alturaTeto, C.y+A.y*dist);
					glEnd();
				}
				C = D;
			}
		}
		glPopMatrix();
	}
};

class Interior : Estrutura{
private:
	static double obtemEscalar(double angulo, double mul = 0){
		// Escalar multiplic�vel por um vetor unit�rio. Conhecendo o �ngulo deste vetor, este
		// escalar levar� o vetor a ser parte da borda de um quadrado arredondado.
		double d = (angulo+45)/90.0;
		double u = min(d-floor(d), ceil(d)-d);
		p2d A = rotaciona(p2d(1,0), 45+90*u);
		// A fun��o [-sin(1) / A.y] levar� o vetor a pertencer � borda de um quadrado perfeito.
		// As outras fun��es diminuem o m�dulo do vetor conforme se aproxima dos v�rtices do quadrado.
		double geraQuad = -sin(1) / A.y;
		double geraCurva = pow((0.5-u)*10, 3)*0.00068 + pow(1.5-u, 22)*0.000007 + mul*pow((0.5-u)*10, 4)*0.00014;
		return geraQuad - geraCurva;
	}

	static p3d intercepta(p3d A, p3d B, double nivel){
	    // Obt�m um ponto que intercepta ao segmento AB
	    return mkp(A.x3+(B.x3-A.x3)*nivel, A.y3+(B.y3-A.y3)*nivel, A.z3+(B.z3-A.z3)*nivel);
	}

	static double dist(p3d A, p3d B){
	    // Dist�ncia entre dois pontos tridimensionais
        return sqrt(pow(A.x3-B.x3, 2) + pow(A.y3-B.y3, 2) + pow(A.z3-B.z3, 2));
	}

public:
	static void geraFatia(double anguloInicial, double anguloFatia, int ProxDesenhaEscada, double smCadeiras[]){
		// Arquibancada e campo
		double distanciaArqInferior = 77;
		double distanciaArqSuperior = 159;
		double alturaArqInferior = 3;
		double alturaArqSuperior = 44;
		double larguraCadeira = 0.9;
		int numDegraus = 45;

		double d1, s1, s2, s3, s4, eX, eY;
		p3d A, B, C, D;
		d1 = distanciaArqInferior;
		s1 = obtemEscalar(anguloInicial);
		s2 = obtemEscalar(anguloInicial+anguloFatia);
		s3 = obtemEscalar(anguloInicial, 1);
		s4 = obtemEscalar(anguloInicial+anguloFatia, 1);
		p2d a = rotaciona(p2d(1,0), anguloInicial);
		p2d b = rotaciona(a, anguloFatia);
		eX = (distanciaArqSuperior-distanciaArqInferior)/mulX;
		eY = (distanciaArqSuperior-distanciaArqInferior)/mulY;
		A = mkp(a.x*d1*s1*mulX, alturaArqInferior, a.y*d1*s1*mulY);
		B = mkp(b.x*d1*s2*mulX, alturaArqInferior, b.y*d1*s2*mulY);
		C = mkp(a.x*(d1+eX)*s3*mulX, alturaArqSuperior, a.y*(d1+eY)*s3*mulY);
		D = mkp(b.x*(d1+eX)*s4*mulX, alturaArqSuperior, b.y*(d1+eY)*s4*mulY);

		// Estrutura de sustenta��o das arquibancadas
		glPushMatrix();
		glBindTexture (GL_TEXTURE_2D, texture_id[2]);
		glColor3f(1, 1, 1);
		glBegin(GL_POLYGON);
		glTexCoord2f(0, 0); glVertex3f(A.x3, -alturaArqInferior, A.z3);
		glTexCoord2f(0, 1); glVertex3f(B.x3, -alturaArqInferior, B.z3);
		glTexCoord2f(alturaArqSuperior/2, 1); glVertex3f(D.x3, alturaArqSuperior, D.z3);
		glTexCoord2f(alturaArqSuperior/2, 0); glVertex3f(C.x3, alturaArqSuperior, C.z3);
		glEnd();
		glBegin(GL_POLYGON);
		glTexCoord2f(0, 0); glVertex3f(A.x3, -alturaArqInferior, A.z3);
		glTexCoord2f(0, 1); glVertex3f(B.x3, -alturaArqInferior, B.z3);
		glTexCoord2f(alturaArqInferior/2, 1); glVertex3f(B.x3, alturaArqInferior, B.z3);
		glTexCoord2f(alturaArqInferior/2, 0); glVertex3f(A.x3, alturaArqInferior, A.z3);
		glEnd();
		glPopMatrix();

		// Concreto de sustenta��o da estrutura
		// Se ProxDesenhaEscada � 0 ent�o ser� gerado uma fatia de acesso (sem cadeiras).
		if (ProxDesenhaEscada == 0){
			glPushMatrix();
			glColor3f(0.6, 0.6, 0.6);
			glLineWidth(8.0);
			glBegin(GL_LINES);
			glVertex3f(A.x3, -alturaArqInferior, A.z3);
			glVertex3f(C.x3, alturaArqSuperior, C.z3);
			glEnd();
			glPopMatrix();
		}

		// Cadeiras da arquibancada
		// fA representa a espessura da fatia no ponto mais distante
		double fA = dist(C, D);
		// fB representa a espessura da fatia no ponto em que se iniciam as cadeiras
		double fB = dist(A, B);
		for (int i = 0; i < numDegraus; i++){
            p3d E = intercepta(A, C, i/double(numDegraus));
            p3d F = intercepta(B, D, i/double(numDegraus));
            p3d G = intercepta(A, C, (i+1)/double(numDegraus));
            p3d H = intercepta(B, D, (i+1)/double(numDegraus));
			// ff representa o n�mero de cadeiras (pode ser real) que ser�o alinhadas horizontalmente no ponto atual
			double ff = dist(E, F) / larguraCadeira;
			glPushMatrix();
			if (ProxDesenhaEscada == 0 || i == 0){
				glBindTexture ( GL_TEXTURE_2D, texture_id[2] );
				smCadeiras[i] = -ff;
			}else
				glBindTexture ( GL_TEXTURE_2D, texture_id[3] );
			glColor3f(1, 1, 1);
			glBegin(GL_POLYGON);
			double fc = smCadeiras[i]+ff;
			if (ProxDesenhaEscada == 1)
                fc = round(fc);
			glTexCoord2f(smCadeiras[i], 0); glVertex3f(E.x3, E.y3, E.z3);
			glTexCoord2f(fc, 0); glVertex3f(F.x3, F.y3, F.z3);
			glTexCoord2f(fc, 1); glVertex3f(F.x3, H.y3, F.z3);
			glTexCoord2f(smCadeiras[i], 1); glVertex3f(E.x3, G.y3, E.z3);
			glEnd();
			smCadeiras[i] += ff;
			geraLinhaDivisoria(mkp(E.x3, G.y3, E.z3), mkp(F.x3, H.y3, F.z3));
			glBindTexture ( GL_TEXTURE_2D, texture_id[2] );
			glColor3f(1, 1, 1);
			glBegin(GL_POLYGON);
			glTexCoord2f(0, 0); glVertex3f(E.x3, G.y3, E.z3);
			glTexCoord2f(0, 1); glVertex3f(F.x3, H.y3, F.z3);
			glTexCoord2f(1, 1); glVertex3f(H.x3, H.y3, H.z3);
			glTexCoord2f(1, 0); glVertex3f(G.x3, G.y3, G.z3);
			glEnd();
			glPopMatrix();
		}

		// Fatia do campo de futebol
		glPushMatrix();
		glColor3f(1, 1, 1);
		glBindTexture ( GL_TEXTURE_2D, texture_id[1] );
		glBegin(GL_TRIANGLES);
		glTexCoord2f(0.5+a.y*s1/1.65, 0.5+a.x*s1/1.35); glVertex3f(A.x3, 0, A.z3);
		glTexCoord2f(0.5+b.y*s2/1.65, 0.5+b.x*s2/1.35); glVertex3f(B.x3, 0, B.z3);
		glTexCoord2f(0.5, 0.5); glVertex3f(0, 0, 0);
		glEnd();
		glPopMatrix();


	}
};

class Complemento : Estrutura{
private:
	static void geraTravessao(p3d A, p3d B){
		glColor3f(1, 1, 1);
		glLineWidth(3.0);
		glBegin(GL_LINES);
		glVertex3f(A.x3, A.y3, A.z3);
		glVertex3f(B.x3, B.y3, B.z3);
		glEnd();
	}

	static void geraTelao(p3d A, p3d B, double h, int lrec = 1){
	    glPushMatrix();
        glBindTexture(GL_TEXTURE_2D, texture_id[5]);
        glColor3f(1, 1, 1);
        glBegin(GL_POLYGON);
        glTexCoord2f(0, 0); glVertex3f(A.x3, A.y3-h, A.z3);
        glTexCoord2f(1, 0); glVertex3f(B.x3, B.y3-h, B.z3);
        glTexCoord2f(1, 1); glVertex3f(B.x3, B.y3, B.z3);
        glTexCoord2f(0, 1); glVertex3f(A.x3, A.y3, A.z3);
        glEnd();
        glPopMatrix();
        if (lrec){
            p3d C = mkp(A.x3*1.001, A.y3, A.z3*1.001);
            p3d D = mkp(B.x3*1.001, B.y3, B.z3*1.001);
            geraTelao(D, C, h, 0);
        }
	}

public:
	static void Inserir(){
		// Traves, placas de propaganda e tel�es
		double escalar = 5.2;
		double dist = 57;

		// Gera traves
		double P[4][3] = {{1,0,0},{1,0.6,0.4},{-0.1,0.6,0},{1,0.6,0}};
		double o[4][3] = {{1,1,1},{1,1,-1},{-1,1,-1},{-1,1,1}};
		double d = dist*mulY;
		for (int i = 0; i < 4; i++){
			p3d pivo = mkp(o[i][0]*P[3][0]*escalar, o[i][1]*P[3][1]*escalar, o[i][2]*(P[3][2]*escalar+d));
			for (int j = 0; j < 3; j++){
				p3d aux = mkp(o[i][0]*P[j][0]*escalar, o[i][1]*P[j][1]*escalar, o[i][2]*(P[j][2]*escalar+d));
				geraTravessao(pivo, aux);
			}
		}

		//Gera placas de propaganda
		glBindTexture(GL_TEXTURE_2D, texture_id[4]);
		vector<p3d> placa;
		double r[4][3] = {{-1,0,1},{-1,1,1},{1,1,1},{1,0,1}};
		for (int i = 0; i < 4; i++)
			placa.push_back(mkp(dist*r[i][0],0.3*escalar*r[i][1],dist+escalar*0.8));
		for (int j = 0; j < 4; j++){
			glColor3f(1, 1, 1);
			glBegin(GL_POLYGON);
			for (int i = 0; i < 4; i++){
				glTexCoord2f(-r[i][0]*(j%2 ? mulY : mulX), r[i][1]);
				glVertex3f(placa[i].x3*mulX*0.88, placa[i].y3, placa[i].z3*mulY);
				p2d P = rotaciona(p2d(placa[i].x3, placa[i].z3), 90);
				placa[i].x3 = P.x; placa[i].z3 = P.y;
			}
			glEnd();
		}

        // Gera os tel�es
		p2d p1 = p2d(0, distanciaTetoInt1+(distanciaTetoInt2-distanciaTetoInt1)/4.0);
		p2d p2 = p2d(0, distanciaTetoInt1);
		double ang = 360 / double(numFatiasExterior);
		for (int i = 0; i < 2; i++){
            p2d B = rotaciona(p1, -ang);
            p2d C = rotaciona(p1, ang);
            p2d D = rotaciona(p2, -ang*0.8);
            p2d E = rotaciona(p2, ang*0.8);
            p2d F = rotaciona(p2, -ang);
            p2d G = rotaciona(p2, ang);
            geraTravessao(mkp(B.x,alturaTeto-alturaEstMetalica*3.0/4.0,B.y), mkp(D.x, alturaTeto-2*alturaEstMetalica, D.y));
            geraTravessao(mkp(C.x,alturaTeto-alturaEstMetalica*3.0/4.0,C.y), mkp(E.x, alturaTeto-2*alturaEstMetalica, E.y));
            geraTelao(mkp(G.x, alturaTeto-alturaEstMetalica, G.y), mkp(F.x, alturaTeto-alturaEstMetalica, F.y), alturaEstMetalica);
			glPopMatrix();
            p1 = rotaciona(p1, 180);
            p2 = rotaciona(p2, 180);
		}

	}
};

// Fun��o callback chamada para fazer o desenho
void Desenha(void){
	// Limpa a janela e o depth buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClear(GL_COLOR_BUFFER_BIT);

	// Habilita transpar�ncia
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    // Gera a arquibancada e o campo
	int numFatiasInterior = 180;
	int delayEscadas = 9; // A cada 9 fatias uma n�o tem cadeiras desenhadas
	double smCadeiras[100];
	memset(smCadeiras, 0, sizeof smCadeiras);
	double anguloFatiaInterior = 360 / double(numFatiasInterior);
	for (int i = 0; i < numFatiasInterior; i++){
		Interior::geraFatia(i*anguloFatiaInterior, anguloFatiaInterior, delayEscadas-i%delayEscadas-1, smCadeiras);
	}

	// Gera o background com uma imagem panor�mica 360.
	Background::desenhaBackground();

	// Gera traves, placas de propaganda e tel�es.
	Complemento::Inserir();

	// Gera os componentes do exterior: teto, piso (exterior) e pilastras.
	double anguloFatiaExterior = 360 / double(numFatiasExterior);
	for (int i = 0; i < numFatiasExterior; i++){
		Exterior::geraFatia(i*anguloFatiaExterior, anguloFatiaExterior, 0);
	}
	for (int i = 0; i < numFatiasExterior; i++){
		Exterior::geraFatia(i*anguloFatiaExterior, anguloFatiaExterior, 1);
	}

	glutSwapBuffers();
}

// Inicializa par�metros de rendering
void Inicializa (void){
	GLfloat luzAmbiente[4]={0.2,0.2,0.2,1.0};
	GLfloat luzDifusa[4]={0.7,0.7,0.7,1.0};		 // "cor"
	GLfloat luzEspecular[4]={1.0, 1.0, 1.0, 1.0};// "brilho"
	GLfloat posicaoLuz[4]={0.0, 20.0, 20.0, 1.0};

	// Capacidade de brilho do material
	GLfloat especularidade[4]={1.0,1.0,1.0,1.0};
	GLint especMaterial = 60;

 	// Especifica que a cor de fundo da janela ser� preta
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);

	// Habilita o modelo de coloriza��o de Gouraud
	glShadeModel(GL_SMOOTH);

	// Define a reflet�ncia do material
	glMaterialfv(GL_FRONT,GL_SPECULAR, especularidade);
	// Define a concentra��o do brilho
	glMateriali(GL_FRONT,GL_SHININESS,especMaterial);

	// Ativa o uso da luz ambiente
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, luzAmbiente);

	// Define os par�metros da luz de n�mero 0
	glLightfv(GL_LIGHT0, GL_AMBIENT, luzAmbiente);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, luzDifusa );
	glLightfv(GL_LIGHT0, GL_SPECULAR, luzEspecular );
	glLightfv(GL_LIGHT0, GL_POSITION, posicaoLuz );

	// Habilita a defini��o da cor do material a partir da cor corrente
	glEnable(GL_COLOR_MATERIAL);
	//Habilita o uso de ilumina��o
	glEnable(GL_LIGHTING);
	// Habilita a luz de n�mero 0
	glEnable(GL_LIGHT0);
	// Habilita o depth-buffering
	glEnable(GL_DEPTH_TEST);

    //angle=45;
    ANGULO = 45;
    rotX = rotY = 0;
	obsX = 0;
    obsY = 2;
    obsZ = 0;//Voltar para 10
    escalaX = escalaY = escalaZ = 1;
}

// Fun��o usada para especificar o volume de visualiza��o
void EspecificaParametrosVisualizacao(void){ //equivalente ao posiciona observador
	// Especifica sistema de coordenadas de proje��o
	glMatrixMode(GL_PROJECTION);
	// Inicializa sistema de coordenadas de proje��o
	glLoadIdentity();

	// Especifica a proje��o perspectiva
    //gluPerspective(angle,fAspect,0.4,500);
    gluPerspective(ANGULO, ASPECTO, 0.4, 1100);

	// Especifica sistema de coordenadas do modelo
	glMatrixMode(GL_MODELVIEW);
	// Inicializa sistema de coordenadas do modelo
	glLoadIdentity();

	// Especifica posi��o do observador e do alvo
    //gluLookAt(0,80,200, 0,0,0, 0,1,0);
    //gluLookAt(obsX, obsY, obsZ, 0,0,0, 0,1,0);
    glTranslatef(-obsX, -obsY, -obsZ);/*Translata a câmera para essas variáveis*/
    glRotatef(rotX,1,0,0);/*Rotacionar a câmera para essas coordenadas*/
    glRotatef(rotY,0,1,0);
}

// Fun��o callback chamada quando o tamanho da janela � alterado
void AlteraTamanhoJanela(GLsizei w, GLsizei h){
	// Para previnir uma divis�o por zero
	if ( h == 0 ) h = 1;

	// Especifica o tamanho da viewport
    glViewport(0, 0, w, h);

	// Calcula a corre��o de aspecto
	//fAspect = (GLfloat)w/(GLfloat)h;
	ASPECTO = (GLfloat)w/(GLfloat)h;

	EspecificaParametrosVisualizacao();
}

// Fun��o callback chamada para gerenciar eventos do mouse
void GerenciaMouse(int button, int state, int x, int y){
	if(state == GLUT_DOWN){
		x_ini = x;
        y_ini = y;
        obsX_ini = obsX;
        obsY_ini = obsY;
        obsZ_ini = obsZ;
        rotX_ini = rotX;
        rotY_ini = rotY;
		bot = button;
	}
	else bot = -1;
	EspecificaParametrosVisualizacao();
	glutPostRedisplay();
}

void motion(int x, int y){
    if(bot == GLUT_LEFT_BUTTON){//Rota��o
        int deltaX = x_ini - x;
        int deltaY = y_ini - y;
        rotX = rotX_ini - deltaY/ SENS_ROT;
        rotY = rotY_ini - deltaX/ SENS_ROT;
     }
     else if (bot == GLUT_RIGHT_BUTTON){//Zoom
         int deltaZ = y_ini - y;
         obsZ = obsZ_ini + deltaZ/ SENS_OBS;
     }
     else if (bot == GLUT_MIDDLE_BUTTON){//Correr
         int deltaX = x_ini - x;
         int deltaY = y_ini - y;
         obsX = obsX_ini + deltaX/ SENS_TRANS;
         obsY = obsY_ini + deltaY/ SENS_TRANS;
     }
     EspecificaParametrosVisualizacao();
     glutPostRedisplay();
}

void GerenciaTecla(unsigned char Key, int x, int y){
	if (Key == 'p' || Key == 'P'){
		panorama_corrente = (panorama_corrente + 1)%MAX_NO_PANORAMAS;
		Desenha();
	}
}

void initTexture (void){
	// Habilita o uso de textura
	glEnable ( GL_TEXTURE_2D );
	// Define a forma de armazenamento dos pixels na textura (1= alihamento por byte)
	glPixelStorei ( GL_UNPACK_ALIGNMENT, 1 );
	// Define quantas texturas ser�o usadas no programa
	glGenTextures (MAX_NO_TEXTURAS+MAX_NO_PANORAMAS, texture_id);  // Quantidade de texturas, vetor de texturas
	// TEXTURA 0
	image_t temp_image;
	panorama_corrente = 0;
	char ref[MAX_NO_TEXTURAS][40] = {"texturas/lona_teto.tga", "texturas/grama.tga", "texturas/concreto.tga",
	"texturas/cadeira.tga", "texturas/publicidade.tga", "texturas/telao.tga"};
	for (int i = 0; i < MAX_NO_TEXTURAS; i++){
		texture_id[i] = 1000+i;
		glBindTexture ( GL_TEXTURE_2D, texture_id[i] );
		tgaLoad  (ref[i], &temp_image, TGA_FREE);
	}
	for (int i = 0; i < MAX_NO_PANORAMAS; i++){
		texture_id[MAX_NO_TEXTURAS+i] = 1000+MAX_NO_TEXTURAS+i;
		glBindTexture (GL_TEXTURE_2D, texture_id[MAX_NO_TEXTURAS+i]);
		char dir[40] = "texturas/panoramas/panorama_0.tga";
		dir[28] = i+'0';
		tgaLoad (dir, &temp_image, TGA_FREE);
	}
}

// Programa Principal
int main(int argc, char** argv){
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(600,600);
	glutCreateWindow("Estadio");
	initTexture();
	glutDisplayFunc(Desenha);
    glutReshapeFunc(AlteraTamanhoJanela);
	glutMouseFunc(GerenciaMouse);
	glutKeyboardFunc(GerenciaTecla);
	glutMotionFunc(motion);
	Inicializa();
	glutMainLoop();
}

